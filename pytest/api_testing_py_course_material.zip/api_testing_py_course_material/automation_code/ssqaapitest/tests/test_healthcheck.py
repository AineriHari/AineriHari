#
# import logging as logger
#
# def test_healthcheck_1():
#     logger.info("Just running h`ealthcheck 1.")